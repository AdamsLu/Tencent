#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
###########################################################################
# Copyright © 1998 - 2026 Tencent. All Rights Reserved.
###########################################################################
"""
Author: Tencent AI Arena Authors

Feature preprocessor and reward design for Gorge Chase PPO.
峡谷追猎 PPO 特征预处理与奖励设计。
"""

import numpy as np

# Map size / 地图尺寸（128×128）
MAP_SIZE = 128.0
# Max monster speed / 最大怪物速度
MAX_MONSTER_SPEED = 5.0
# Max distance bucket / 距离桶最大值
MAX_DIST_BUCKET = 5.0
# Max flash cooldown / 最大闪现冷却步数
MAX_FLASH_CD = 2000.0
# Max buff duration / buff最大持续时间
MAX_BUFF_DURATION = 50.0


def _norm(v, v_max, v_min=0.0):
    """Normalize value to [0, 1].

    将值归一化到 [0, 1]。
    """
    v = float(np.clip(v, v_min, v_max))
    return (v - v_min) / (v_max - v_min) if (v_max - v_min) > 1e-6 else 0.0


class Preprocessor:
    def __init__(self):
        self.reset()

    def reset(self):
        self.step_no = 0
        self.max_step = 200
        self.last_min_monster_dist_norm = 0.5
        self.stage=0
        self.agent_x=0
        self.agent_z=0
        self.stall_steps=0

    def _is_blocked_cell(self, map_info, r, c):
        """
        判断局部地图中的某个格子是否为障碍/墙。
        约定：越界视为撞墙；map_info[row][col] == 0 视为不可通过。
        """
        if map_info is None:
            return False

        rows = len(map_info)
        cols = len(map_info[0]) if rows > 0 else 0

        if r < 0 or r >= rows or c < 0 or c >= cols:
            return True

        return float(map_info[r][c]) == 0.0


    def _check_endpoint_clear(self, map_info, start_r, start_c, dr, dc, step_count):
        # 检查路径终点是否撞墙
        nr = start_r + dr * step_count
        nc = start_c + dc * step_count
        return not self._is_blocked_cell(map_info, nr, nc)


    def _refine_legal_action_by_wall(self, legal_action, map_info):
        """
        基于局部地图，手动过滤 16 个动作。
        如果动作路径上任意一步撞墙，则该动作置为 0。
        闪现只判定终点是否撞墙。
        """
        if map_info is None or len(map_info) == 0 or len(map_info[0]) == 0:
            return legal_action

        rows = len(map_info)
        cols = len(map_info[0])

        # 英雄位于局部地图中心
        center_r = rows // 2
        center_c = cols // 2

        # 16 个动作定义: action_id -> (dr, dc, step_count)
        action_to_delta = {
            # 移动 8 个动作（1格）
            0:  (0,  1, 1),   # 右
            1:  (-1, 1, 1),   # 右上
            2:  (-1, 0, 1),   # 上
            3:  (-1,-1, 1),   # 左上
            4:  (0, -1, 1),   # 左
            5:  (1, -1, 1),   # 左下
            6:  (1,  0, 1),   # 下
            7:  (1,  1, 1),   # 右下

            # 闪现 8 个动作
            8:  (0,  1, 10),  # 向右闪现10格
            9:  (-1, 1, 8),   # 向右上闪现8格
            10: (-1, 0, 10),  # 向上闪现10格
            11: (-1,-1, 8),   # 向左上闪现8格
            12: (0, -1, 10),  # 向左闪现10格
            13: (1, -1, 8),   # 向左下闪现8格
            14: (1,  0, 10),  # 向下闪现10格
            15: (1,  1, 8),   # 向右下闪现8格
        }

        refined = legal_action[:]

        for action_id in range(16):
            # 如果环境本来就判非法，就不用再测
            if refined[action_id] == 0:
                continue

            dr, dc, step_count = action_to_delta[action_id]

            # 只要路径中任意一步撞墙，就屏蔽该动作，闪现只判定终点
            ok = self._check_endpoint_clear(
                map_info=map_info,
                start_r=center_r,
                start_c=center_c,
                dr=dr,
                dc=dc,
                step_count=step_count,
            )

            if not ok:
                refined[action_id] = 0

        # 如果全部被过滤掉，回退为原 legal_action，避免策略彻底无动作可选
        if sum(refined) == 0:
            return legal_action

        return refined

    def feature_process(self, env_obs, last_action):
        """Process env_obs into feature vector, legal_action mask, and reward.

        将 env_obs 转换为特征向量、合法动作掩码和即时奖励。
        """
        observation = env_obs["observation"]
        frame_state = observation["frame_state"]
        env_info = observation["env_info"]
        map_info = observation["map_info"]
        legal_act_raw = observation["legal_action"]

        self.step_no = observation["step_no"]
        self.max_step = env_info.get("max_step", 200)

        # Hero self features (4D) / 英雄自身特征
        hero = frame_state["heroes"]
        hero_pos = hero["pos"]
        hero_x_norm = _norm(hero_pos["x"], MAP_SIZE)
        hero_z_norm = _norm(hero_pos["z"], MAP_SIZE)
        flash_cd_norm = _norm(hero["flash_cooldown"], MAX_FLASH_CD)
        buff_remain_norm = _norm(hero["buff_remaining_time"], MAX_BUFF_DURATION)

        hero_feat = np.array([hero_x_norm, hero_z_norm, flash_cd_norm, buff_remain_norm], dtype=np.float32)

        # Monster features (7D x 2) / 怪物特征
        monsters = frame_state.get("monsters", [])
        monster_feats = []
        
        for i in range(2):
            if i < len(monsters):
                m = monsters[i]
                is_in_view = float(m.get("is_in_view", 0))
                m_pos = m["pos"]
                m_hero_relative_direction=m["hero_relative_direction"]
                m_monster_interval=m["monster_interval"]
                if is_in_view:
                    m_x_norm = _norm(m_pos["x"], MAP_SIZE)
                    m_z_norm = _norm(m_pos["z"], MAP_SIZE)
                    m_speed_norm = _norm(m.get("speed", 1), MAX_MONSTER_SPEED)

                    # Euclidean distance / 欧式距离
                    raw_dist = np.sqrt((hero_pos["x"] - m_pos["x"]) ** 2 + (hero_pos["z"] - m_pos["z"]) ** 2)
                    dist_norm = _norm(raw_dist, MAP_SIZE * 1.41)
                else:
                    m_x_norm = 0.0
                    m_z_norm = 0.0
                    m_speed_norm = 0.0
                    dist_norm = 1.0
                monster_feats.append(
                    np.array([is_in_view, m_x_norm, m_z_norm, m_speed_norm, dist_norm,m_hero_relative_direction,m_monster_interval], dtype=np.float32)
                )
            else:
                monster_feats.append(np.zeros(7, dtype=np.float32))

        # Local map features (25D) / 局部地图特征（5×5网格）
        map_feat = np.zeros(25, dtype=np.float32)
        if map_info is not None and len(map_info) >= 11:
            center = len(map_info) // 2
            flat_idx = 0
            for row in range(center - 2, center + 3):  # ← 改这里：从 center-2, center+2 改为 center-2, center+3
                for col in range(center - 2, center + 3):  # ← 改这里：从 center-2, center+2 改为 center-2, center+3
                    if 0 <= row < len(map_info) and 0 <= col < len(map_info[0]):
                        map_feat[flat_idx] = float(map_info[row][col] != 0)
                    flat_idx += 1
        
        # 物件特征(7D)
        organs=frame_state["organs"]
        min_dist=1
        if organs:
            organs_sub_type=organs[0]["sub_type"]
            organs_config_id=organs[0]["config_id"]
            organs_status=organs[0]["status"]
            organs_pos=organs[0]["pos"]
            o_x_norm = _norm(organs_pos["x"], MAP_SIZE)
            o_z_norm = _norm(organs_pos["z"], MAP_SIZE)
            organs_hero_l2_distance=organs[0]["hero_l2_distance"] # 
            organs_hero_relative_direction=organs[0]["hero_relative_direction"] # 
            for i in range(1,len(organs)):
                raw_dist = np.sqrt((hero_pos["x"] - organs[i]["pos"]["x"]) ** 2 + (hero_pos["z"] - organs[i]["pos"]["z"]) ** 2)
                dist_norm = _norm(raw_dist, MAP_SIZE * 1.41)
                if dist_norm<min_dist:
                    min_dist=dist_norm
                    organs_sub_type=organs[i]["sub_type"]
                    organs_config_id=organs[i]["config_id"]
                    organs_status=organs[i]["status"]
                    organs_pos=organs[i]["pos"]
                    o_x_norm = _norm(organs_pos["x"], MAP_SIZE)
                    o_z_norm = _norm(organs_pos["z"], MAP_SIZE)
                    organs_hero_l2_distance=organs[i]["hero_l2_distance"] # 
                    organs_hero_relative_direction=organs[i]["hero_relative_direction"] # 
            organs_feats=np.array([organs_sub_type,organs_config_id,organs_status,o_x_norm,o_z_norm,organs_hero_l2_distance,organs_hero_relative_direction], dtype=np.float32)
            
        else:
            organs_feats=np.array([0,0,0,0,0,0,0], dtype=np.float32)
            

        # # 环境特征（3D）
        # print(env_info)
        # finished_steps=env_info["finished_steps"]
        # flash_cooldown=env_info["flash_cooldown"]
        # monster_speed=env_info["monster_speed"]
        # env_feats=[]
        # env_feats.append(
        #     np.array([finished_steps,flash_cooldown,monster_speed],dtype=np.float32)
        # )

        # Legal action mask (16D) / 合法动作掩码,但没作为特征传递给网络
        legal_action = [1] * 16
        if isinstance(legal_act_raw, list) and legal_act_raw:
            if isinstance(legal_act_raw[0], bool):
                for j in range(min(16, len(legal_act_raw))):
                    legal_action[j] = int(legal_act_raw[j])
            else:
                valid_set = {int(a) for a in legal_act_raw if 0 <= int(a) < 16}
                legal_action = [1 if j in valid_set else 0 for j in range(16)]

        if sum(legal_action) == 0:
            legal_action = [1] * 16

        # 再基于局部地图做手动撞墙过滤
        legal_action = self._refine_legal_action_by_wall(legal_action, map_info)

        # 最终兜底
        if sum(legal_action) == 0:
            legal_action = [1] * 16

        # Progress features (2D) / 进度特征
        step_norm = _norm(self.step_no, self.max_step)
        survival_ratio = step_norm
        progress_feat = np.array([step_norm, survival_ratio], dtype=np.float32)

        # Concatenate features / 拼接特征
        feature = np.concatenate(
            [
                hero_feat,            #4
                monster_feats[0],     #7
                monster_feats[1],     #7
                map_feat,             #25
                organs_feats,         #7
                # env_feats,            #3
                progress_feat,        #2
            ]
        )

        # Step reward / 即时奖励
        cur_min_dist_norm = 128
        for m_feat in monster_feats:
            if m_feat[0] > 0:
                cur_min_dist_norm = min(cur_min_dist_norm, m_feat[4])

        # 生存奖励，稠密奖励，鼓励保持距离，避免被怪物追上。
        survive_reward = 0.01

        # 追逐奖励，鼓励与怪物保持距离。距离增加给予正奖励，距离减少给予负奖励。使用 clip 限制单步奖励幅度，避免过大波动。
        delta_dist = cur_min_dist_norm - self.last_min_monster_dist_norm
        dist_shaping = 0.15 * np.clip(delta_dist, -0.1, 0.1)
        self.last_min_monster_dist_norm = cur_min_dist_norm

        # 危险惩罚，距离过近时给予负奖励，鼓励保持安全距离。距离小于0.15给予较大负奖励，距离小于0.25给予较小负奖励。
        danger_penalty = 0.0
        if cur_min_dist_norm < 0.03:
            danger_penalty = -0.05
        elif cur_min_dist_norm < 0.07:
            danger_penalty = -0.02

        # 站桩惩罚：如果英雄位置没有明显变化（距离变化小于1e-3），则给予微小负奖励，鼓励移动。
        move_dist = abs(self.agent_x - hero_x_norm) + abs(self.agent_z - hero_z_norm)
        if move_dist < 1e-3:
            self.stall_steps += 1
        else:
            self.stall_steps = 0
        stall_penalty = -min(0.01 * self.stall_steps, 0.05)
        self.agent_x=hero_x_norm
        self.agent_z=hero_z_norm

        reward = [survive_reward + dist_shaping + danger_penalty + stall_penalty]

        return feature, legal_action, reward
